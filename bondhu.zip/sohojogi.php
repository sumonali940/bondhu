<!DOCTYPE HTML>
<html class="no-js" lang="en-US">
    <head>
		<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>রক্তবন্ধু</title>
<meta name="description" content="আমরা রক্তবন্ধু, রক্তের সম্পর্ক গড়ি ।
রক্তবন্ধু স্বেচ্ছায় রক্তদাতাদের জন্য তৈরি একটি ওয়েবসাইট, আপনি ও একজন রক্তবন্ধু হতে আজই রেজিস্ট্রেশন  করুন।">
<meta name="keywords" content="রক্তবন্ধু,roktobondhu,blood,blood donate,bd blood donate,blood donate website,roktobondhu.com">
<meta name="author" content="ASHIK">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="image/x-icon" href="assets/img/icon.png" />


  <meta property="og:url"           content="https://roktobondhu.com" />
  <meta property="og:type"          content="website" />
  <meta property="og:title"         content="রক্তবন্ধু" />
  <meta property="og:description"   content="আমরা রক্তবন্ধু, রক্তের সম্পর্ক গড়ি ।"/>
  <meta property="og:image"         content="https://roktobondhu.com/thumbnail5.jpg" /> 


<meta name="twitter:title" content="রক্তবন্ধু">
<meta name="twitter:description" content="আমরা রক্তবন্ধু, রক্তের সম্পর্ক গড়ি ।">
<meta name="twitter:image" content="https://roktobondhu.com/thumbnail.jpg">
<meta name="twitter:card" content="summary_large_image">		
		<!-- Stylesheet -->
		<!-- Fontawesome CSS -->
        <!-- <link rel="stylesheet" href="assets/css/fontawesome-all.min.css"> -->
        <script src="https://use.fontawesome.com/c08c022230.js"></script>
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
		<!-- Owl Carousel css -->
		<link rel="stylesheet" type="text/css" href="assets/css/owl.theme.default.min.css" media="all" />
		<link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css" media="all" />
		<!-- normalize -->
        <link rel="stylesheet" href="assets/css/normalize.css">
			<!-- Google fonts -->
		<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,600,700" rel="stylesheet"> 
		<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Xanh+Mono&display=swap" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css2?family=Archivo+Black&display=swap" rel="stylesheet"> 
		<!-- Main Stylesheet -->
		
		<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css" rel="stylesheet" />
		<link rel="stylesheet" href="assets/css/default.css">
        <link rel="stylesheet" href="assets/css/style.css">
		<link rel="stylesheet" type="text/css" href="assets/css/responsive.css" media="all" />

		<!-- Global site tag (gtag.js) - Google Analytics -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=UA-125225951-1"></script>
		<script>
		  window.dataLayer = window.dataLayer || [];
		  function gtag(){dataLayer.push(arguments);}
		  gtag('js', new Date());

		  gtag('config', 'UA-125225951-1');
		</script>

	<!-- Load Facebook SDK for JavaScript -->
      <div id="fb-root"></div>
      <script>
        window.fbAsyncInit = function() {
          FB.init({
            xfbml            : true,
            version          : 'v6.0'
          });
        };

        (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));</script>

      <!-- Your customer chat code -->
<!--       <div class="fb-customerchat"
        attribution=setup_tool
        page_id="105201280823180"
  theme_color="#00A5FF"
  logged_in_greeting=" "
  logged_out_greeting=" ">
      </div> -->

      <script data-ad-client="ca-pub-4331100589850935" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

    </head>
		<body>
        <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->
		
		<!-- Start Preloader Area -->
		<!-- <div id="preloader"></div> -->
		<!-- End Preloader Area -->
		<div class="full-main">
		<div class="main-area">
		<!-- Start Header Area -->
		<section class="header-area">
			<div class="container">
				<div class="row">
					<div class="col-xl-4 col-md-4">
						<div class="logo_area">
							<h2> <a href="/">
								<!-- <img src="assets/images/logo.png" alt="" /> <span>রক্তবন্ধু</span>   -->
								<img src="assets/img/logo.png" alt="" />
							</a></h2>
						</div>
						<div class="nav_icon"> 
							<!-- <a class="nav-bars" href="#"><i class="fas fa-bars"></i></a> -->
							<a class="nav-bars" href="#">Menu</a>
						</div>
					</div>
					<div class="col-xl-8 col-md-8"> 
						<div class="header_menu_area"> 
							<ul>
								<li><a class="active" href="/" >হোম</a></li>
								<li><a href="/platelet">প্লাটিলেট</a></li>
								<li><a href="/thalassemia">থ্যালাসেমিয়া</a></li>
								<li><a href="/volunteers">ভলান্টিয়ার্স</a></li>
								<li><a href="/sohojogi">সহযোগী সংগঠন</a></li>
								<li><a href="/blog">ব্লগ</a></li>
																<li><a href="/login">লগইন </a></li>
								<li><a href="/registration">রেজিস্ট্রেশন</a></li> 
								
							</ul>
						</div>
					</div>
				</div>
			</div>
		</section>		
		<!-- End Header Area -->


<!-- 
		<div class="oxg_banner">
			<a href="tel:01765018344"><img src="assets/oxg.png" alt="oxg banner"></a>
			<a href="#"  class="oxg_close">X</a>
		</div> --><header class="header2-area">
			<div class="container">
				<div class="row">
					<div class="col-xl-12">
						<div class="table-heading"> 
							<h2>সহযোগী সংগঠনঃ</h2>
						</div>
					</div>  
				</div>
				<div class="row section_padding">
										<div class="col-md-4">
						 <div class="info">
						 	<h2><a target="_blank" href="http://coderitsolution.com">Coder IT Solution</a></h2>
						 	<h2>Fulbari,  Dinajpur</h2>
						 	<p>01751331330</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>মানব উন্নয়ন সংঘ (মাউস)</h2>
						 	<h2></h2>
						 	<p>০১৭১৬৬২৬৪৮৭</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>বিজয় শান্তি সংঘ</h2>
						 	<h2></h2>
						 	<p>01743774835</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>ঢাকাস্থ পঞ্চগড়বাসী</h2>
						 	<h2></h2>
						 	<p>..</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2><a href="https://www.facebook.com/DesignPlaceDP" target="_blank">Design Place </a></h2>
						 	<h2>গ্রাফিক পার্টনার</h2>
						 	<p><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="0e6a6b7d6769607e626f6d6b6a7e4e69636f6762206d6163">[email&#160;protected]</a></p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>সুরাহা ব্লাড ফাউন্ডেশন</h2>
						 	<h2></h2>
						 	<p>...</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>মানবতার সৈনিক রক্তদান সংগঠন </h2>
						 	<h2>চান্দিনা, কুমিল্লা</h2>
						 	<p>01868451493</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>মাতৃছায়া ব্লাড ফাউন্ডেশন</h2>
						 	<h2>মনোহরদী, নরসিংদী</h2>
						 	<p>01761698300</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>খুটাখালী ব্লাড কল্যাণ সোসাইটি </h2>
						 	<h2>খুটাখালী, চকরিয়া, কক্সবাজার।</h2>
						 	<p>01824645100</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>ফ্রেন্ডস ব্লাড ব্যাংক </h2>
						 	<h2>ঠাকুরগাঁও ( পীরগঞ্জ উপজেলা) </h2>
						 	<p>01723630728</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>কিশোরগঞ্জ ব্লাড ফাউন্ডেশন </h2>
						 	<h2>করিমগঞ্জ, কিশোরগঞ্জ </h2>
						 	<p>01835082543</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>সত্যের জ্যোতি ব্লাড ব্যাংক </h2>
						 	<h2>(কুমিল্লা শাখা)</h2>
						 	<p>01836500168</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>জাগ্রত সংঘ, পঞ্চগড় </h2>
						 	<h2>(রক্তের গ্রুপ নির্ণয়ের সহযোগী সংগঠন) </h2>
						 	<p>01838998899</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>স্বপ্নছোঁয়া দরিদ্র কল্যাণ তহবিল</h2>
						 	<h2>সোনাহার বাজার, দেবীগঞ্জ পঞ্চগড়</h2>
						 	<p>01723264585</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>উৎস-একটি স্বেচ্ছাসেবী সামাজিক সংগঠন</h2>
						 	<h2>তেঁতুলিয়া,পঞ্চগড়</h2>
						 	<p>০১৭৭৪০৯৬৯৩৬</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>আমরা করবো রক্ত দান -AKRD</h2>
						 	<h2>মাজার গেট, আগ্রাবাদ, চট্টগ্রাম</h2>
						 	<p>01869339929</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>বাংলাদেশে রেড ক্রিসেন্ট সোসাইটি</h2>
						 	<h2>দিনাজপুর সরকারি কলেজ ইউনিট, দিনাজপুর।</h2>
						 	<p>01796929875</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>একতা ব্লাড ফাউন্ডেশন</h2>
						 	<h2>গাউছিয়া, নারায়ণগঞ্জ </h2>
						 	<p>01863246506</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>বিজ্ঞানের আলো (মানব সেবায়, আমরা সবাই)</h2>
						 	<h2>হরিপুর, চাটমোহর, পাবনা </h2>
						 	<p>01977013637</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>প্রতিশ্রুতি -The Promise</h2>
						 	<h2>চারখাই, বিয়ানীবাজার, সিলেট</h2>
						 	<p>01610212124, 01790957247</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>গোল্ডেন সোসাইটি ফাউন্ডেশন</h2>
						 	<h2>কাবিলা বাজার, বুড়িচং, কুমিল্লা </h2>
						 	<p>01687769043, 01949914711</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>ব্লাড ফর লাইফ ডোমার </h2>
						 	<h2>ডোমার, নীলফামারী</h2>
						 	<p>01780640908</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>স্বপ্নযাত্রা ফাউন্ডেশন</h2>
						 	<h2>মনোহরদী, নরসিংদী</h2>
						 	<p>০১৭৯৯২৮০৫১৮</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>সোনালী হাসি মানব কল্যাণ সংস্থা</h2>
						 	<h2>রংপুর সদর </h2>
						 	<p>0 1799-149202</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>"অঝর"  স্বেচ্ছায় রক্তদানকারী একটি স্বেচ্ছাসেবী সংগঠন।</h2>
						 	<h2>ইসলাম নগর,ঠাকুরগাঁও রোড,ঠাকুরগাঁও। </h2>
						 	<p>01738267776</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>ড্রিম লাইফ এসোসিয়েশন </h2>
						 	<h2>নিউটাউন নতুন ৬ নং উপশহর দিনাজপুর   </h2>
						 	<p>০১৭০৫৮০৮৩৭৮</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>বাংলাদেশ ছাত্র সমাজ টিম </h2>
						 	<h2>চান্দিনা মাধাইয়া,  কুমিল্লা</h2>
						 	<p>ফোন : ০১৯৩৩-০২৮৫৩৭ । ০১৬২৩-৮৩৪০০৮</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>হোমনা জয়পুর ইউনিয়ন ব্লাড ফাউন্ডেশন </h2>
						 	<h2> হোমনা, কুমিল্লা </h2>
						 	<p>01885826750</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>রক্তের বন্ধন </h2>
						 	<h2>চুনারুঘাট, হবিগঞ্জ</h2>
						 	<p>01316474292</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>উৎসাহ সামাজিক সংগঠন (USS)। </h2>
						 	<h2>চট্টগ্রাম </h2>
						 	<p>০১৮৫৬৫০১৮৮১</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>সূর্যোদয় সেবা সংঘ (SSS)</h2>
						 	<h2>কামালপুর, লক্ষীকুন্ডা,ঈশ্বরদী, পাবনা।</h2>
						 	<p>01729741625, 01974553066</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>প্রচেষ্টা বিডি </h2>
						 	<h2> এফ,রোড়ঃ১৩,বাড়ীঃ৪৬৮ বসুন্ধরা আ/এ, ঢাকা</h2>
						 	<p>01770016973</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>প্রত্যাশা রক্তদান ও সামাজিক সেবা সংস্থা</h2>
						 	<h2>বগুড়া </h2>
						 	<p>01783052828</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>Change of Community Organization (CCO)</h2>
						 	<h2>Joyag, Sonaimuri, Noakhali. </h2>
						 	<p>01766879111 </p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>Blood Democracy  </h2>
						 	<h2>District: Laxmipur, Ramgonj, Narayanan pur</h2>
						 	<p>01306581550</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>রক্তের সন্ধানে সিরাজগঞ্জ (R.S.S) </h2>
						 	<h2>সিরাজগঞ্জ সদর  </h2>
						 	<p>01909823266</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>রক্তবীজ </h2>
						 	<h2>চট্টগ্রাম  মহানগর </h2>
						 	<p>01305987402</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>Jhenaidah Blood Donate Club</h2>
						 	<h2>ঝিনাইদহ </h2>
						 	<p>01723264008</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>নবজীবন রক্তদান সংগঠন  </h2>
						 	<h2>পূর্বধলা , নেত্রকোনা </h2>
						 	<p>01911313875</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>Nababgonj Blood Donors Club</h2>
						 	<h2>নবাবগঞ্জ, ঢাকা</h2>
						 	<p>01918841829</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>উৎসাহ রক্তদান সংগঠন </h2>
						 	<h2>মগবাজার, ঢাকা</h2>
						 	<p>০১৭১৩-৯২৮৭৯১</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>ফ্রিডম ব্লাড ব্যাংক</h2>
						 	<h2>নেভী হাসপাতাল গেইট,সিদ্দিক বিল্ডিং ৩য় তলা,ইপিজেড,চট্টগ্রাম।</h2>
						 	<p>01787795343</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>খেদমতে খলক ফাউন্ডেশন  </h2>
						 	<h2>উত্তরা, ঢাকা </h2>
						 	<p>01673589538</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>Charity Foundation</h2>
						 	<h2>সাটিয়াজুরী , চুনারুঘাট , হবিগঞ্জ ।</h2>
						 	<p>01932158051</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>কোটচাঁদপুর ব্লাড ব্যাংক,                     এক‌টি স্বেচ্ছা‌সেবী সংগঠন </h2>
						 	<h2>কোটচাঁদপুর, ঝিনাইদহ</h2>
						 	<p>01971857475</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>ডা. এড্রিক বেকার ব্লাড ফাউন্ডেশন </h2>
						 	<h2>সাভার, ঢাকা</h2>
						 	<p>01754925692</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>রক্তবিন্দু-ইন্দুরকানী ব্লাড ডোনার্স ফোরাম।</h2>
						 	<h2>ইন্দুরকানী ,পিরোজপুর।</h2>
						 	<p>016186-44488</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>আজমপুর দারুল উলূম মাদরাসা ও এতিমখানা ব্লাড ব্যাংক </h2>
						 	<h2>উত্তরা ৬, ঢাকা</h2>
						 	<p>01617058283</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>Chapai Nawabganj Blood Donation Club   </h2>
						 	<h2>চাঁপাইনবাবগঞ্জ</h2>
						 	<p>01726193006</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>সমাজ সংশোধনী সংস্থা</h2>
						 	<h2>মাদ্রাসা রোড, বাস স্ট্যান্ড, চাঁদপুর সদর, চাঁদপুর</h2>
						 	<p>01640927543</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>বি.জি.ফ্রেন্ডস সোসাইটি </h2>
						 	<h2>লোহাগাড়া, সাতকানিয়া, চট্টগ্রাম  </h2>
						 	<p>টেলিফোনঃ 09638631975</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>পাপড়ি  রক্তদান ফাউন্ডেশন  </h2>
						 	<h2>নেত্রকোনা </h2>
						 	<p>01518343272</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>ব্লাড & হার্ট </h2>
						 	<h2>সেনবাগ, নোয়াখালী</h2>
						 	<p>01847100783</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>রক্তের বন্ধন যুব সংগঠন   </h2>
						 	<h2>সি. আই. পাড়া, পিরোজপুর সদর, পিরোজপুর   </h2>
						 	<p>০১৩১৭৫১৫১৬১, ০১৬৩৪০০০৯০৩</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>প্রগ্রেস হেল্প এইড ফাউন্ডেশন    (PHAP)   </h2>
						 	<h2>ফেনী</h2>
						 	<p>০১৭০৯৭৭১০৬৭, ০১৮৭৪২৮৬১৬০</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>বাঙ্গরা বাজার থানা রক্তদান সংগঠন</h2>
						 	<h2>মুরাদনগর, কুমিল্লা।</h2>
						 	<p>01766-730100</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>খিদমাহ ব্লাড ব্যাংক, কুলাউড়া</h2>
						 	<h2>মৌলভীবাজার, কুলাউড়া  </h2>
						 	<p>01952019521</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>Naogaon Blood Circle (নওগাঁ ব্লাড সার্কেল)  </h2>
						 	<h2>নওগাঁ, রাজশাহী </h2>
						 	<p>   ️01797664301</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>মুক্ত আকাশ </h2>
						 	<h2>ফাসিলাডাঙ্গা, সদর দিনাজপুর</h2>
						 	<p>01737187081</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>‌রেডলাইফ স্বেচ্ছা‌সেবী সামা‌জিক সংগঠন</h2>
						 	<h2>পীরগঞ্জ, ঠাকুরগাঁও</h2>
						 	<p>০১৭৬৭৩৯০৩০২</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>ঠাকুরগাঁও স্বেচ্ছাসেবী রক্তদান সংস্থা  </h2>
						 	<h2>ঠাকুরগাঁও </h2>
						 	<p>01761178214</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>Youth Blood And Social Foundation</h2>
						 	<h2>ঠাকুরগাঁও জেলা শাখা  </h2>
						 	<p>01402041879</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>মোমেনা অনলাইন রক্তদান সংগঠন  </h2>
						 	<h2>বগুড়া </h2>
						 	<p>01713739400</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>ধামোর ব্লাড ফাউন্ডেশন </h2>
						 	<h2>আটোয়ারী উপজেলা, পঞ্চগড় </h2>
						 	<p>01737433727</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>সেবক বন্ধু স্বেচ্ছাসেবী সংগঠন, রংপুর।  </h2>
						 	<h2>পান্ডার দিঘী পরশুরাম থানা সংলগ্ন, রংপুর</h2>
						 	<p>01722426399, 01882206819</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>রাধানগর সমাজকল্যাণ সংগঠন</h2>
						 	<h2>আটোয়ারী উপজেলা, পঞ্চগড় </h2>
						 	<p>আবু হাসান বাবু ০১৭২৪২০১৪৬৬</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>ইশা ব্লাড ব্যাংক</h2>
						 	<h2>উত্তরা ঢাকা, সেক্টর ১২, রোড ১২, হাউস ৭   </h2>
						 	<p>০১৯৪২০১৪৭৮৬</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>মানবতার ডাক সামাজিক সংগঠন </h2>
						 	<h2>কাদিরজঙ্গল ইউনিয়ন, করিমগঞ্জ, কিশোরগঞ্জ।</h2>
						 	<p>01933789003</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>স্বপ্ন ছোঁয়া সংগঠন বাংলাদেশ  </h2>
						 	<h2>কেন্দ্রীয় কার্যালয়ঃ হারবাং , চকরিয়া , কক্সবাজার , বাংলাদেশ। </h2>
						 	<p>01925973877 (মিজানুর রহমান)</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>স্বপ্নীল সমাজ সেবা সংগঠন</h2>
						 	<h2>ভোলা </h2>
						 	<p>+8809638362989, 01712154703 (Rabby)</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>Akota Blood Donar Association </h2>
						 	<h2>হাসনাবাদ মনোহরগঞ্জ, কুমিল্লা  </h2>
						 	<p>01781043401 (সাইমুন হাসান)</p>
						 </div>
					</div>
										<div class="col-md-4">
						 <div class="info">
						 	<h2>দৃষ্টি নন্দন স্বেচ্ছায় রক্তদান সংগঠন    </h2>
						 	<h2>টেংগনমারী, জলঢাকা, নীলফামারী</h2>
						 	<p>01755472312</p>
						 </div>
					</div>
										
				</div>	
			</div>
		</header>
	</div>
	<div class="main-footer">
		<!-- Start Notice Area -->
		<div class="container">
	<div class="row">
		<div class="col-md-12"> 
			<br>
			<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
			<!-- Roktobondhu -->
			<ins class="adsbygoogle"
			     style="display:block"
			     data-ad-client="ca-pub-4331100589850935"
			     data-ad-slot="5393622206"
			     data-ad-format="auto"
			     data-full-width-responsive="true"></ins>
			<script>
			     (adsbygoogle = window.adsbygoogle || []).push({});
			</script>

			<br>
		</div>
	</div> 
</div> 

<section class="notice-area"> 
	<div class="container"> 
		<div class="row"> 
			<div class="col-xl-12"> 
				<div class="notice_bord text-center"> 
				 
				<p><span>নোটিশঃ</span> রক্তবন্ধুর সাথে কাজ করতে চাইলে, রক্তবন্ধু সম্পর্কে জানতে, পাসওয়ার্ড ভুলে গেলে যোগাযোগ করুন <a href="tel:01716626487, 01778951824
"><span class="engFont"> 01716626487, 01778951824</span></a></p>
				<p><a class="text-black btn-btn-danger" target="_blank" href="/details"><span class="eng"></span></a> <a class="btn btn-danger" target="_blank" href="/details">রক্তবন্ধু সম্পর্কে  বিস্তারিত জানতে ক্লিক করুন </a> </p>
				</div>
			</div>
		</div>
	</div>
</section>		<!-- End Notice Area -->
		
		<!-- Start Footer ARea -->
		<footer class="footer-area"> 
			<div class="container"> 
				<div class="row"> 
					<div class="col-xl-6 col-md-6 col-sm-6 col-12"> 
						<div class="footer-left"> 
							<p>© 2018-2022 রক্তবন্ধু || all Right reserved </p>
						</div>
					</div>
					<div class="col-xl-6 col-md-6 col-sm-6 col-12"> 
						<div class="footer-right"> 
							<p> Developed By <a target="_blank" href="https://coderitsolution.com/"> Coder IT Solution</a></p>
						</div>
					</div>
				</div>
			</div>
		</footer>	
		<!-- Rnd Footer ARea -->
	</div>
	</div>
		<!-- Js Files -->
		<!-- modernizr -->
        <script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>
		<!-- jQuery -->
        <script type="text/javascript" src="assets/js/vendor/jquery-3.2.1.min.js"></script>
		<!-- Bootstrap Popper -->
        <script src="assets/js/popper.js"></script>
		<!-- Bootstrap -->
        <script src="assets/js/bootstrap.min.js"></script>
		<!-- Owl Carousel JS -->
        <script src="assets/js/config.js"></script>
        <script src="assets/js/util.js"></script>
        <script src="assets/js/jquery.emojiarea.js"></script>
        <script src="assets/js/emoji-picker.js"></script>
        <script src="assets/js/owl.carousel.min.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

        <script src="assets/js/html2canvas.min.js"></script>
		<!-- Custom Scripts -->
        <script src="assets/js/main.js"></script>
        <script src="assets/js/inna.js"></script>
		  <script>
		  $( function() {
		    $( "#birthday" ).datepicker({
		      changeMonth: true,
		      changeYear: true,
		      dateFormat: 'yy-mm-dd'
		    });
		  } );
		  </script>
        <script>
        	$('.eye_btn').click(function(){
        		$('.hide_box').show();
        		return false;
        	});

        	$('#code').keyup(function(){
		      var code = $('#code').val();
		      var uid = $('#uid').val();
		        $.ajax({ 
		            'url':'ajaxRequest.php',
		            'type':'POST',
		            'data' : {
		                'code':code,
		                'uid':uid
		            }, 
		            'success': function(data3) {
		              $('#showN').html(data3);
		              $('.x_number').hide();
		          }

		        });
		    }); 
 

        </script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.min.js"></script>
		<script>
		$(document).ready(function() {
		   $('.district').select2();
		});
		</script>

		
    </body>
</html>