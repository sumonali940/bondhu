<!DOCTYPE HTML>
<html class="no-js" lang="en-US">
    <head>
		<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>রক্তবন্ধু</title>
<meta name="description" content="আমরা রক্তবন্ধু, রক্তের সম্পর্ক গড়ি ।
রক্তবন্ধু স্বেচ্ছায় রক্তদাতাদের জন্য তৈরি একটি ওয়েবসাইট, আপনি ও একজন রক্তবন্ধু হতে আজই রেজিস্ট্রেশন  করুন।">
<meta name="keywords" content="রক্তবন্ধু,roktobondhu,blood,blood donate,bd blood donate,blood donate website,roktobondhu.com">
<meta name="author" content="ASHIK">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="image/x-icon" href="assets/img/icon.png" />


  <meta property="og:url"           content="https://roktobondhu.com" />
  <meta property="og:type"          content="website" />
  <meta property="og:title"         content="রক্তবন্ধু" />
  <meta property="og:description"   content="আমরা রক্তবন্ধু, রক্তের সম্পর্ক গড়ি ।"/>
  <meta property="og:image"         content="https://roktobondhu.com/thumbnail5.jpg" /> 


<meta name="twitter:title" content="রক্তবন্ধু">
<meta name="twitter:description" content="আমরা রক্তবন্ধু, রক্তের সম্পর্ক গড়ি ।">
<meta name="twitter:image" content="https://roktobondhu.com/thumbnail.jpg">
<meta name="twitter:card" content="summary_large_image">		
		<!-- Stylesheet -->
		<!-- Fontawesome CSS -->
        <!-- <link rel="stylesheet" href="assets/css/fontawesome-all.min.css"> -->
        <script src="https://use.fontawesome.com/c08c022230.js"></script>
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
		<!-- Owl Carousel css -->
		<link rel="stylesheet" type="text/css" href="assets/css/owl.theme.default.min.css" media="all" />
		<link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.min.css" media="all" />
		<!-- normalize -->
        <link rel="stylesheet" href="assets/css/normalize.css">
			<!-- Google fonts -->
		<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,600,700" rel="stylesheet"> 
		<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Xanh+Mono&display=swap" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css2?family=Archivo+Black&display=swap" rel="stylesheet"> 
		<!-- Main Stylesheet -->
		
		<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css" rel="stylesheet" />
		<link rel="stylesheet" href="assets/css/default.css">
        <link rel="stylesheet" href="assets/css/style.css">
		<link rel="stylesheet" type="text/css" href="assets/css/responsive.css" media="all" />

		<!-- Global site tag (gtag.js) - Google Analytics -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=UA-125225951-1"></script>
		<script>
		  window.dataLayer = window.dataLayer || [];
		  function gtag(){dataLayer.push(arguments);}
		  gtag('js', new Date());

		  gtag('config', 'UA-125225951-1');
		</script>

	<!-- Load Facebook SDK for JavaScript -->
      <div id="fb-root"></div>
      <script>
        window.fbAsyncInit = function() {
          FB.init({
            xfbml            : true,
            version          : 'v6.0'
          });
        };

        (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));</script>

      <!-- Your customer chat code -->
<!--       <div class="fb-customerchat"
        attribution=setup_tool
        page_id="105201280823180"
  theme_color="#00A5FF"
  logged_in_greeting=" "
  logged_out_greeting=" ">
      </div> -->

      <script data-ad-client="ca-pub-4331100589850935" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

    </head>
		<body>
        <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->
		
		<!-- Start Preloader Area -->
		<!-- <div id="preloader"></div> -->
		<!-- End Preloader Area -->
		<div class="full-main">
		<div class="main-area">
		<!-- Start Header Area -->
		<section class="header-area">
			<div class="container">
				<div class="row">
					<div class="col-xl-4 col-md-4">
						<div class="logo_area">
							<h2> <a href="/">
								<!-- <img src="assets/images/logo.png" alt="" /> <span>রক্তবন্ধু</span>   -->
								<img src="assets/img/logo.png" alt="" />
							</a></h2>
						</div>
						<div class="nav_icon"> 
							<!-- <a class="nav-bars" href="#"><i class="fas fa-bars"></i></a> -->
							<a class="nav-bars" href="#">Menu</a>
						</div>
					</div>
					<div class="col-xl-8 col-md-8"> 
						<div class="header_menu_area"> 
							<ul>
								<li><a class="active" href="/" >হোম</a></li>
								<li><a href="/platelet">প্লাটিলেট</a></li>
								<li><a href="/thalassemia">থ্যালাসেমিয়া</a></li>
								<li><a href="/volunteers">ভলান্টিয়ার্স</a></li>
								<li><a href="/sohojogi">সহযোগী সংগঠন</a></li>
								<li><a href="/blog">ব্লগ</a></li>
																<li><a href="/login">লগইন </a></li>
								<li><a href="/registration">রেজিস্ট্রেশন</a></li> 
								
							</ul>
						</div>
					</div>
				</div>
			</div>
		</section>		
		<!-- End Header Area -->


<!-- 
		<div class="oxg_banner">
			<a href="tel:01765018344"><img src="assets/oxg.png" alt="oxg banner"></a>
			<a href="#"  class="oxg_close">X</a>
		</div> -->	 	
	 	<div class="card-area">
	 		<div class="container">
	 			<div class="row">
	 				<div class="col-md-12">
	 					<div class="download-btn text-center">
 							<a href="#" class="btn btn-inline-block btn-danger btn-rounded" id="btnDownload">Download Card</a>
 						</div>
	 					<div class="bloodCard">
	 						
	 						<div id="card" class="">
	 							<div class="c_header">
	 								<div class="c_header_left c_avatar">
  										<img id="blah" src="#" alt=" "/>
	 								</div>
	 								<div class="c_group">A+</div>
	 								<div class="c_header_left c_header_right"> 
	 									<img src="assets/images/card/logo2.png" alt="logo">
	 								</div> 
	 							</div>

	 							<div class="c_details">
 									<h4><span id="c_o_name">বন্ধু ব্লাড ব্যাংক</span></h4> 
 									<p><b>Blood Group: </b><span id="c_o_blood">A+</span></p> 
 									<p><b>Mobile: </b><span id="c_o_mobile">017xxxxxxxx</span></p> 
 									<p><b>Address: </b><span id="c_o_address">xxxxxx, Bangladesh.</span></p> 
 								</div>

	 							<div class="c_footer">
	 								<p>বন্ধু ব্লাড ব্যাংক</p>
	 							</div>
	 						</div>

	 						<div class="colors">
	 							<ul>
	 								<li><img id="cbg_0" src="assets/images/card/bg.jpg" alt="BG 0"></li> 
	 								<li><img id="cbg_1" src="assets/images/card/colors/c1.png" alt="BG 1"></li> 
	 								<li><img id="cbg_2" src="assets/images/card/colors/c2.png" alt="BG 1"></li> 
	 								<li><img id="cbg_3" src="assets/images/card/colors/c3.png" alt="BG 1"></li> 
	 								<li><img id="cbg_4" src="assets/images/card/colors/c4.png" alt="BG 1"></li> 
	 								<li><img id="cbg_5" src="assets/images/card/colors/c5.png" alt="BG 1"></li> 
	 							</ul>
	 						</div>
	 					</div>
	 					<div class="row">
	 						<div class="col-md-6 offset-md-3"> 
	 							<div class="card-form">
									<form action="">
										<div class="form-group">
											<label for="">Name:</label>
											<input type="text" class="form-control" name="c_name" placeholder="Type your Name..." id="c_name">
										</div>

										<div class="form-group">
											<label for="blood_group">Blood Group:</label>
											<select name="blood_group" class="form-control custom-select" id="blood_group">
											<option value="A+">A+</option>
											<option value="A-">A-</option>
											<option value="B+">B+</option>
											<option value="B-">B-</option>
											<option value="O+">O+</option>
											<option value="O-">O-</option>
											<option value="AB+">AB+</option>
											<option value="AB-">AB-</option>
										</select>
										</div>

										<div class="form-group">
											<label for="c_mobile">Mobile:</label>
											<input type="text" class="form-control" name="c_mobile" placeholder="Mobile Number" id="c_mobile">
										</div>
										<div class="form-group">
											<label for="c_address">Address:</label>
											<input type="text" class="form-control" name="c_address" placeholder="Address" id="c_address">
										</div>

										<div class="form-group">
											<label for="c_mobile">Photo</label>
											<input type='file' id="imgInp" class="form-control"  />
										</div>
 										<small class="text-center">Scroll top to Check your Card.</small>
 										<br> <br> 
									</form>
								</div>

	 						</div>
	 					</div>
	 					


	 				</div>
	 			</div>
	 		</div>
	 	</div>
		<!-- Start socila Area -->
		<section class="socila_area"> 
			<div class="container"> 
				<div class="row"> 
					<div class="col-xl-12"> 
						<div class="social_area"> 
							<ul>
								<li><a href="https://facebook.com/groups/roktobondhu/"> <img src="assets/images/fb.jpg" alt="" /></a></li> 
								<li class="last_item"><a href="https://play.google.com/store/apps/details?id=com.weroktobondhu.newwebview"><img src="assets/images/play.png" alt="" /></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End socila Area -->
	</div>
	<div class="main-footer">
		<!-- Start Notice Area -->
		<div class="container">
	<div class="row">
		<div class="col-md-12"> 
			<br>
			<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
			<!-- Roktobondhu -->
			<ins class="adsbygoogle"
			     style="display:block"
			     data-ad-client="ca-pub-4331100589850935"
			     data-ad-slot="5393622206"
			     data-ad-format="auto"
			     data-full-width-responsive="true"></ins>
			<script>
			     (adsbygoogle = window.adsbygoogle || []).push({});
			</script>

			<br>
		</div>
	</div> 
</div> 

<section class="notice-area"> 
	<div class="container"> 
		<div class="row"> 
			<div class="col-xl-12"> 
				<div class="notice_bord text-center"> 
				 
				<p><span>নোটিশঃ</span> রক্তবন্ধুর সাথে কাজ করতে চাইলে, রক্তবন্ধু সম্পর্কে জানতে, পাসওয়ার্ড ভুলে গেলে যোগাযোগ করুন <a href="tel:01716626487, 01778951824
"><span class="engFont"> 01716626487, 01778951824</span></a></p>
				<p><a class="text-black btn-btn-danger" target="_blank" href="/details"><span class="eng"></span></a> <a class="btn btn-danger" target="_blank" href="/details">রক্তবন্ধু সম্পর্কে  বিস্তারিত জানতে ক্লিক করুন </a> </p>
				</div>
			</div>
		</div>
	</div>
</section>		<!-- End Notice Area -->
		
		<!-- Start Footer ARea -->
		<footer class="footer-area"> 
			<div class="container"> 
				<div class="row"> 
					<div class="col-xl-6 col-md-6 col-sm-6 col-12"> 
						<div class="footer-left"> 
							<p>© 2018-2022 রক্তবন্ধু || all Right reserved </p>
						</div>
					</div>
					<div class="col-xl-6 col-md-6 col-sm-6 col-12"> 
						<div class="footer-right"> 
							<p> Developed By <a target="_blank" href="https://coderitsolution.com/"> Coder IT Solution</a></p>
						</div>
					</div>
				</div>
			</div>
		</footer>	
		<!-- Rnd Footer ARea -->
	</div>
	</div>
		<!-- Js Files -->
		<!-- modernizr -->
        <script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>
		<!-- jQuery -->
        <script type="text/javascript" src="assets/js/vendor/jquery-3.2.1.min.js"></script>
		<!-- Bootstrap Popper -->
        <script src="assets/js/popper.js"></script>
		<!-- Bootstrap -->
        <script src="assets/js/bootstrap.min.js"></script>
		<!-- Owl Carousel JS -->
        <script src="assets/js/config.js"></script>
        <script src="assets/js/util.js"></script>
        <script src="assets/js/jquery.emojiarea.js"></script>
        <script src="assets/js/emoji-picker.js"></script>
        <script src="assets/js/owl.carousel.min.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

        <script src="assets/js/html2canvas.min.js"></script>
		<!-- Custom Scripts -->
        <script src="assets/js/main.js"></script>
        <script src="assets/js/inna.js"></script>
		  <script>
		  $( function() {
		    $( "#birthday" ).datepicker({
		      changeMonth: true,
		      changeYear: true,
		      dateFormat: 'yy-mm-dd'
		    });
		  } );
		  </script>
        <script>
        	$('.eye_btn').click(function(){
        		$('.hide_box').show();
        		return false;
        	});

        	$('#code').keyup(function(){
		      var code = $('#code').val();
		      var uid = $('#uid').val();
		        $.ajax({ 
		            'url':'ajaxRequest.php',
		            'type':'POST',
		            'data' : {
		                'code':code,
		                'uid':uid
		            }, 
		            'success': function(data3) {
		              $('#showN').html(data3);
		              $('.x_number').hide();
		          }

		        });
		    }); 
 

        </script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.min.js"></script>
		<script>
		$(document).ready(function() {
		   $('.district').select2();
		});
		</script>

		
    </body>
</html>